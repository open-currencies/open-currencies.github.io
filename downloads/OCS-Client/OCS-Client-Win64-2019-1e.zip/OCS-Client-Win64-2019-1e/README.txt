This is the README file for the portable OCS Client Application.
----------------------------------------------------------------
IMPORTANT: Your private keys are stored in the subdirectory

/conf/keys

of your OCS-Client folder. Please make sure that your private
key files get neither stolen nor lost.
